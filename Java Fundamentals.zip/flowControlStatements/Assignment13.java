/* Write a program to print prime numbers between 10 and 99.*/

package flowControlStatements;

public class Assignment13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=99;
		int flag;
		while(a<b)
		{
			flag=0;
			for(int i=2;i<=a/2;i++)
			{
				if(a%i==0)
				{
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println(a);
			}
			a++;
		}
	}

}
