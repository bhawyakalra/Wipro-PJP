/* Write a program to check if a given integer number is Positive, Negative, or Zero. */
package flowControlStatements;
import java.util.Scanner;
public class Assignment1 
{
 public static void main(String[] args)
 {
	   Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		if(i>0)
		{
			System.out.println("The given integer is Positive");
		}
		else if(i<0)
		{
			System.out.println("The given integer is Negative");
		}
		else 
		{
			System.out.println("The given integer is Zero");
		}
		sc.close();
 }

}
