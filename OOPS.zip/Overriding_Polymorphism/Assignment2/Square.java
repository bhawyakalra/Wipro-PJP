package Overriding_Polymorphism.Assignment2;

class Square extends shape
{
	public void draw()
	{
		System.out.println("Drawing square");
	}
	public void erase()
	{
		System.out.println("Erasing square");
	}
}

