/* Write a program to receive a color code from the user (an Alphabhet). 

The program should then print the color name, based on the color code given. 

The following are the color codes and their corresponding color names.
R->Red, B->Blue, G->Green, O->Orange, Y->Yellow, W->White. 

If color code provided by the user is not valid then print "Invalid Code". */
package flowControlStatements;
import java.util.Scanner;
public class Assignment8 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char ch=sc.next().charAt(0);
		switch(ch)
		{
			case 'R':
			{
			System.out.println(ch+"->Red");
			break;
			}
			case 'B':
			{
			System.out.println(ch+"->Blue");
			break;
			}
			case 'G':
			{
			System.out.println(ch+"->Green");
			break;
			}
			case 'O':
			{
			System.out.println(ch+"->Orange");
			break;
			}
			case 'Y':
			{
		    System.out.println(ch+"->Yellow");
			break;
			}
			case 'W':
			{
			System.out.println(ch+"->White");
			break;
			}
            default:
            {
            System.out.println("Invalid Code");
			}
		}
       sc.close();
	}

}
