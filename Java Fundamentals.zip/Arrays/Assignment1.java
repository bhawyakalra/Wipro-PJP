/* Write a program to initialize an integer array and print the sum and average of the array.*/

package Arrays;

public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[]{10,20,30,40,50,60};
		int sum=0;
		float avg=0;
		for(int i=0;i<arr.length;i++)
		{
			sum+=arr[i];
		}
		System.out.println("Sum of array is: "+sum);
		avg=sum/6;
		System.out.println("Average of array is: "+avg);
	}

}
