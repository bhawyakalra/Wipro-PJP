/*Initialize a character variable in a program and 
print 'Alphabhet' if the initialized value is an alphabhet, 
print 'Digit' if the initialized value is a number, and 
print 'Special Character', if the initialized value is anything else.*/
package flowControlStatements;

public class Assignment5
{

	public static void main(String[] args)
	{
		char a='c';
		if((a>=65&&a<=90)||(a>=97&&a<=122))
			System.out.print("The given character is Alphabet");
		else if(a>=48&&a<=57)
			System.out.println("The given character is a number");
		else 
		    System.out.println("The given character is a special character");
		}
}
