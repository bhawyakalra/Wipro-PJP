package Overriding_Polymorphism.Assignment1;

class Apple extends Fruit
{
	Apple(String name,String taste)
	{
		super(name,taste);
	}
	void eat()
	{
		System.out.println("The name of fruit is: "+name);
		System.out.println("The taste of fruit is: "+taste);
	}
}