/*Write a Java program to find if the given number is prime or not.

Example1)
C:\>java Sample 
O/P: Please enter an integer number 

Example2)
C:\>java Sample 1
O/P:1 is neither prime nor composite

Example3)
C:\>java Sample 0
O/P: 0 is neither prime nor composite
 
Example4)
C:\>java Sample 10
O/P: 10 is not a prime number

Example5)
C:\>java Sample 7
O/P : 7 is a prime number*/
package flowControlStatements;

public class Assignment14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length==0)
		{
			System.out.println("Please enter an integer number");
			System.exit(0);
		}
		else 
		{
			int n=Integer.parseInt(args[0]);
			if((n==0)||(n==1))
			{
				System.out.println(n+" is neither prime nor composite");
			}
			else 
			{
				int flag=1;
				for(int i=2;i<=n/2;i++)
				{
					if(n%i==0)
					{
						flag=0;
						break;
					}
				}
				if(flag==1)
					System.out.println(n+" is a prime number");
				else 
					System.out.println(n+" is not a prime number");
			}
		}
	}

}
