/* Write a program to print first 5 values which are divisible by 2, 3, and 5.*/

package flowControlStatements;

public class Assignment19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int counter=0;
		int i=1;
		while(counter!=5)
		{
			if((i%2==0)&&(i%3==0)&&(i%5==0))
			{
				System.out.println(i);
				counter++;
			}
			i++;
		}
	}

}
