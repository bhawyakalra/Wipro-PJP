/* Write a program to find the largest 2 numbers and 
 * the smallest 2 numbers in the given array.
 */

package Arrays;

import java.util.Arrays;

public class Assignment5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[]{1,30,-1,20,3,2,10};
		Arrays.sort(arr);
		System.out.println("First largest number is: "+arr[arr.length-1]);
		System.out.println("Second largest number is: "+arr[arr.length-2]);
		System.out.println("First smallest number is: "+arr[0]);
		System.out.println("Second smallest number is: "+arr[1]);
		/* Using Sorting 
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr.length-i-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		for(int num:arr)
		{
			System.out.println(num);
		}
		System.out.println("First largest number is: "+arr[arr.length-1]);
		System.out.println("Second largest number is: "+arr[arr.length-2]);
		System.out.println("First smallest number is: "+arr[0]);
		System.out.println("Second smallest number is: "+arr[1]);*/
	}

}
