package Overriding_Polymorphism.Assignment2;

	class shape
	{
		public void draw()
		{
			System.out.println("Drawing shapes");
		}
	   public void erase()
		{
			System.out.println("Erasing shapes");
		}
	}
