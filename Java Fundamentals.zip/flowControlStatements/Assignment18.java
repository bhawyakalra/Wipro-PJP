/* Write a Java program to find if the given number is palindrome or not

Example1)
C:\>java Sample 110011
O/P: 110011 is a palindrome

Example2)
C:\>java Sample 1234
O/P: 1234 is not a palindrome*/
package flowControlStatements;

import java.util.Scanner;

public class Assignment18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int rem=0,rev=0,temp=0;
		temp=n;
		while(n>0)
		{
			rem= n%10;
			rev=rev*10+rem;
			n=n/10;
		}
		if(rev==temp)
		{
			System.out.print(temp+" is a palindrome");
		}
		else
		{
			System.out.print(temp+" is not a palindrome");
		}
		sc.close();
	}

}
