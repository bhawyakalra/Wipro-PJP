package Inheritance.Assignment3;

class college_Student extends Student
{
	private String college_name;
	private String year;
	public college_Student(String n,String db,int id,String cn,String y)
	{
		super(n,db,id);
		college_name=cn;
		year=y;
	}
	void showData4()
	{
		System.out.println("Name: "+super.name);
		System.out.println("Date of birth: "+super.dob);
		System.out.println("Id of student: "+super.studentId);
		System.out.println("Name of college: "+college_name);
		System.out.println("Year of studying: "+year);
    }
}