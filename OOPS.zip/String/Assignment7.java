/*Given a string, if the first or last chars are 'x', return the string without those 'x' chars, otherwise return the string unchanged. 

If the input is "xHix", then output is "Hi".
If the input is "America", then the output is "America".*/
package String;

import java.util.Scanner;

public class Assignment7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		int len=str.length();
		if((str.charAt(0)=='x')||(str.charAt(len-1)=='x'))
		{
			System.out.println(str.substring(1,len-1));
		}
		else
		{
			System.out.println(str);
		}
		sc.close();
	}

}
