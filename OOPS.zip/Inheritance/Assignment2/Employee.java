package Inheritance.Assignment2;
class Employee extends Person
{
	double salary;
	int year;
	String in_no;
	Employee(double salary,String name,int year,String in_no)
	{
		super(name);
		this.salary=salary;
		this.year=year;
		this.in_no=in_no;
	}
	void display()
	{
		System.out.println("Employee name: "+name);
		System.out.println("Salary: "+salary);
		System.out.println("Year of starting: "+year);
		System.out.println("National Insurance Number: "+in_no);
	}
}

