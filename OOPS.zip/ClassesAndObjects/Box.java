/*Create a class Box that uses a parameterized constructor to initialize the dimensions of a box.The dimensions of the Box are width, height, depth. The class should have a method that can return the volume of the box. 
 * Create an object of the Box class and test the functionalities.*/

package ClassesAndObjects;
class Box
{
double width,height,depth;
Box(double width,double height,double depth)
{
this.width=width;
this.height=height;
this.depth=depth;
}
double calVolume()
{
return width*height*depth;
}
public static void main(String args[])
{
Box obj=new Box(10,18.2,30.6);
System.out.print("Volume of box is: "+obj.calVolume());
}
}
