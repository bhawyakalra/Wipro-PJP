package Inheritance.Assignment2;
class Person
{
	protected String name;
    Person(String name)
	{
		this.name=name;
	}
}	
