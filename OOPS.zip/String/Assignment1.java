/* Write a Program to check whether a given String is Palindrome or not.
*/
package String;

import java.util.Scanner;

public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String str=sc.next();
		/*String rev="";
		for(int i=str.length()-1;i>=0;i--)
		{
			rev=rev+str.charAt(i);
		}
		if(str.equalsIgnoreCase(rev))
		{
			System.out.println("Palindrome");
		}
		else
		{
		    System.out.println("Not Palindrome");
		}*/
		StringBuffer s1=new StringBuffer(str);
		s1=s1.reverse();
		String str1=s1.toString();
		if(str.equalsIgnoreCase(str1))
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not Palindrome");

		}
		sc.close();
	}

}
