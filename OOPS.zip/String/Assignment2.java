/*Write a java program that will concatenate 2 strings and return the result. The result should be in lowercase.

Note:If the concatenation creates a double-char, then one of the characters need to be omitted.

Example1)
i/p:Sachin,Tendulkar
o/p:sachin tendulkar

Example2)
i/p:Mark,kate
o/p:markate*/
package String;

import java.util.Scanner;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();
		String s2=sc.next();
		s1=s1.toLowerCase();
		s2=s2.toLowerCase();
		int len1=s1.length()-1;
		int len2=s2.length();
		char ch1=s1.charAt(len1);
		char ch2=s2.charAt(0);
		if(ch1==ch2)
		{
			String s3=s2.replace(ch2,' ');
			String s4=s2.substring(1,len2);
			System.out.println(s1.concat(s4));
		}
		else
		{
			System.out.println(s1.concat(" ").concat(s2));
		}
		sc.close();
	}

}
