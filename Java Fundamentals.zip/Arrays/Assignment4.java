/* Initialize an integer array with ascii values and print the 
 * corresponding character values in a single row.
 */

package Arrays;

public class Assignment4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[]{65,97,81,84,79,73,90};
		for(int i=0;i<arr.length;i++)
		{
			System.out.println((char)arr[i]);
		}
	}

}
