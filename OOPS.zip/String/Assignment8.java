/* Write a Java program that accepts a string (with * in it). The program should return a new string in which the following characters are removed-*,the characters that are to the left and right of *

Example1)
i/p:ab*cd
o/p:ad*/
package String;

import java.util.Scanner;

public class Assignment8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str=sc.next();
		StringBuffer sb=new StringBuffer(str);
		for(int i=0;i<sb.length();i++)
		{
			if((sb.charAt(i))=='*')
			{
				sb.delete(i-1,i);
				sb.delete(i,i+1);
			}
		}
		str=sb.toString();
		str=str.replace("*","");
		System.out.println(str);
		sc.close();
	}

}
