/* Write a program to print * in Floyds format (using for and while loop)
*
*  *
*  *   *

Example1)
C:\>java Sample 
O/P: Please enter an integer number

Example2)
C:\>java Sample 3
O/P :
*
*  * 
*  *  **/
package flowControlStatements;

public class Assignment16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length==0)
		{
			System.out.println("Please enter an integer number");
			System.exit(0);
		}
		else 
		{
			int n=Integer.parseInt(args[0]);
			/*for(int i=0;i<n;i++)
			{
				for(int j=0;j<=i;j++)
				{
					System.out.print("*"+" ");
				}
				System.out.println();
			}*/
			int i=0,j;
			while(i<n)
			{
				j=0;
				while(j<=i)
				{
					System.out.print("*"+" ");
					j++;
				}
				i++;
				System.out.println();
			}
		}
	}

}
