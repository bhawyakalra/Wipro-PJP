/*Given two strings, a and b, print a new string which is made of the following combination-first character of a, the first character of b, second character of a, second character of b and so on. 
Any characters left, will go to the end of the result.

Example1)
i/p:Hello,World
o/p:HWeolrllod*/
package String;

import java.util.Scanner;

public class Assignment9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two strings ");
		System.out.println("Enter first string: ");
		String str1=sc.next();
		System.out.println("Enter second string: ");
		String str2=sc.next();
		int len1=str1.length();
		int len2=str2.length();
		int max=Math.max(len1,len2);
		StringBuffer str3=new StringBuffer("");
		for(int i=0;i<max;i++)
		{
			if(i<len1)
				str3.append(str1.charAt(i));
			if(i<len2)
				str3.append(str2.charAt(i));
		}
		System.out.println(str3);
		sc.close();
	}

}
