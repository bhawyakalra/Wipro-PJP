package Inheritance.Assignment3;

class Person
{
	protected String name;
	protected String dob;
	public Person(String n,String db)
	{
		name=n;
		dob=db;
	}
	void showData1()
	{
		System.out.println("Name: "+name);
		System.out.println("Date of Birth: "+dob);
	}
}