package Overriding_Polymorphism.Assignment1;
class Fruit
{
	protected String name;
	protected String taste;
	protected int size;
	Fruit(String name,String taste)
	{
		this.name=name;
		this.taste=taste;
	}
	void eat()
	{
		System.out.println("The name of fruit: ");
		System.out.println("Taste is: ");
	}
}
