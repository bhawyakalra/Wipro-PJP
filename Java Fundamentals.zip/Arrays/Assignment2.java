/* Write a program to initialize an integer array and find the maximum 
 * and minimum value of the array.*/
 

package Arrays;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr={10,30,5,14,15,2};
		int max=arr[0];
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
			}
		}
		System.out.println("Maximum element of the array is: "+max);
		int min=arr[0];
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]<max)
			{
				min=arr[i];
			}
		}
		System.out.println("Minimum element of the array is: "+min);
	}

}
