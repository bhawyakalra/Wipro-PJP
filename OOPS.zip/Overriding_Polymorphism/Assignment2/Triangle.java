package Overriding_Polymorphism.Assignment2;
class Triangle extends shape
{
	public void draw()
	{
		System.out.println("Drawing triangle");
	}
	public void erase()
	{
		System.out.println("Erasing triangle");
	}
}
