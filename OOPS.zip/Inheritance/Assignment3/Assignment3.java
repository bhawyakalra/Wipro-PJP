/* Create a school application with a class called Person. Create name and dateOfBirth as member variables.

Create a class called Teacher that inherits from the Person class. The teacher will have additional properties like salary, and the subject that the teacher teaches.

Create a class called Student that inherits from Person class. This class will have a member variable called studentId. 

Create a class called College Student that inherits from Student class. This class will have collegeName, the year in which the student is studying (first/second/third/fourth) etc.

Create objects of each of this classes, invoke and test the methods that are available in these classes.*/
package Inheritance.Assignment3;

public class Assignment3
{
	public static void main(String args[])
	{
		Person p1=new Person("Bhawya","6-11-1997");
		p1.showData1();
		Teacher t1=new Teacher("Jyoti","12-10-1970",10000.00,"DBMS");
		t1.showData2();
		Student s1=new Student("Ayush","3-11-1997",101);
		s1.showData3();
		college_Student cs=new college_Student("Bhavita","12-3-1997",102,"Chitkara University","first");
	    cs.showData4();
	}
}
