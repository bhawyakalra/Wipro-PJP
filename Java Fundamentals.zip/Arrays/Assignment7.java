/* Write a program to remove the duplicate elements in an array and print the same.
Example)
I/P:{12,34,12,45,67,89}
O/P:{12,34,45,67,89}*/
package Arrays;

public class Assignment7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={12,34,12,45,67,89};
		int n=arr.length;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(arr[i]==arr[j])
				{
					for(int k=j;k<n-1;k++)
					{
						arr[k]=arr[k+1];
					}
					n=n-1;
				}
			}
		}
		for(int l=0;l<n;l++)
		{
			System.out.println(arr[l]);
		}
	}

}
