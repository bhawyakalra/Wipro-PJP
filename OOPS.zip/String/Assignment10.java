/*Given a string and an integer n, print a new string made of n repetitions of the last n characters of the string. 
You may assume that n is between 0 and the length of the string, inclusive. 

Example1)
i/p:Wipro,3
o/p:propropro*/
package String;

import java.util.Scanner;

public class Assignment10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str1=sc.next();
		int n=sc.nextInt();
		int len=str1.length();
		String str2=str1.substring(len-n,len);
		String str3="";
		for(int i=0;i<n;i++)
		{
			str3=str3+str2;
		}
		System.out.println(str3);
sc.close();
	}

}
