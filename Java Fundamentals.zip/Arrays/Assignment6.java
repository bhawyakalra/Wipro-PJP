/* Write a program to initialize an array and print them in a sorted order.*/

package Arrays;

import java.util.Arrays;

public class Assignment6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[]{10,20,2,19,-2,6,100};
		Arrays.sort(arr);
		for(int x:arr)
		{
			System.out.println(x);
		}
	}

}
