/*Create  a base class Fruit with name ,taste and size as its attributes. 

Create a method called eat() which describes the name of the fruit and its taste. 

Inherit the same in 2 other classes Apple and Orange and override the eat() method to represent each fruit taste.*/
package Overriding_Polymorphism.Assignment1;
class Assignment1
{
	public static void main(String args[])
	{
		Fruit a=new Apple("Apple","Sweet");
		a.eat();
		Fruit o=new Orange("Orange","Sour");
		o.eat();
	}
}