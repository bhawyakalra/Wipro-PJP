/* Write a program to check if a given integer number is odd or even.*/
package flowControlStatements;
import java.util.Scanner;
public class Assignment2 
{
    public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int i;
		i=sc.nextInt();
		if(i%2==0)
			System.out.println("Given number is even");
		else 
			System.out.println("Given number is odd");
		sc.close();
		}
}
