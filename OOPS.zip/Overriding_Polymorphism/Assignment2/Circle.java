package Overriding_Polymorphism.Assignment2;

class Circle extends shape
{
	public void draw()
	{
		System.out.println("Drawing circle");
	}
	public void erase()
	{
		System.out.println("Erasing circle");
	}
}
