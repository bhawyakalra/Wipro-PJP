package Inheritance.Assignment3;

class Student extends Person
{
	protected int studentId;
	Student(String name,String db,int id)
	{
		super(name,db);
		studentId=id;
	}
	void showData3()
	{
		System.out.println("Name: "+super.name);
		System.out.println("Date of birth: "+super.dob);
		System.out.println("Id of a student: "+studentId);
	}
	
}

