package Inheritance.Assignment3;

class Teacher extends Person
{
	protected double salary;
    protected String subject_name;
	public Teacher(String name,String db,double sal,String sub_name)
	{
		super(name,db);
		salary=sal;
		subject_name=sub_name;
	}
	void showData2()
	{
		System.out.println("Name: "+super.name);
		System.out.println("Date of Birth: "+super.dob);
		System.out.println("Salary: "+salary);
		System.out.println("Name of the subject: "+subject_name);
	}
}
