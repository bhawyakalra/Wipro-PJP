/* Write a program to check if a given number is prime or not.*/

package flowControlStatements;

import java.util.Scanner;

public class Assignment12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int flag=1;
		for(int i=2;i<=n/2;i++)
		{
			if(n%i==0)
			{
				flag=0;
				break;
			}
		}
		if(flag==1)
		{
			System.out.println("Prime");
		}
		else 
		{
			if(flag==0)
			{
				System.out.println("Not Prime");
			}
		}
       sc.close();
	}

}
