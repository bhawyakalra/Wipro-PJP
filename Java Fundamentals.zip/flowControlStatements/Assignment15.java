/* Write a program to print the sum of all the digits of a given number.

Example1) 
I/P:1234
O/P:10*/

package flowControlStatements;

public class Assignment15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=1234;
		int rem=0,sum=0;
		for(int i=0;n>0;i++)
		{
		rem=n%10;
		sum+=rem;
		n=n/10;
		}
		System.out.println(sum);
	}

}
